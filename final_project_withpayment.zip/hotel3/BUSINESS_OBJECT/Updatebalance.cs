﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BUSINESS_OBJECT
{
   public class Updatebalance
    {
        public string cname { get; set; }
        public string amount{ get; set; }
    }
}
