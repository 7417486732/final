﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

using System.Globalization;
using System.Configuration;
using BUSINESS_OBJECT;

namespace DAL
{
    public class register_dal
    {


         SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["hotel_res"].ToString());
        public string User_Registration(register_object user_details)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Sign_Up", con);
            cmd.CommandType = CommandType.StoredProcedure;
            try
            {
                cmd.Parameters.AddWithValue("@Name", user_details.name);
                cmd.Parameters.AddWithValue("@Phone", user_details.phone);
                cmd.Parameters.AddWithValue("@Mail", user_details.email);
                cmd.Parameters.AddWithValue("@Password", user_details.password);
                cmd.Parameters.AddWithValue("@Country", user_details.country);
                cmd.Parameters.AddWithValue("@City", user_details.city);
                cmd.Parameters.AddWithValue("@PinCode", user_details.pincode);
                cmd.Parameters.AddWithValue("@SecurityQuestion", user_details.securityquestion);
                cmd.Parameters.AddWithValue("@SecurityAnswer", user_details.securityanswer);
                cmd.Parameters.AddWithValue("@Balance", user_details.balance);
                return cmd.ExecuteNonQuery().ToString();
            }
            catch (Exception show_error)
            {
                throw show_error;
            }
            finally
            {
                cmd.Dispose();
                con.Close();
                con.Dispose();
            }
        }

        public object User_Login(register_object user_details)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("U_login", con);
            cmd.CommandType = CommandType.StoredProcedure;
            try
            {
                cmd.Parameters.AddWithValue("@name", user_details.name);
                cmd.Parameters.AddWithValue("@pass", user_details.password);
                return cmd.ExecuteScalar();
            }
            catch (Exception show_error)
            {
                throw show_error;
            }

            finally
            {
                cmd.Dispose();
                con.Close();
                con.Dispose();
            }
        }

        public string Hotel_Insert(hotel_object hotel_details)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("insert_hotel_sp", con);
            cmd.CommandType = CommandType.StoredProcedure;
            try
            {
                cmd.Parameters.AddWithValue("@Hotel_Name", hotel_details.hotel_name);
                cmd.Parameters.AddWithValue("@City_Name", hotel_details.city_name);
                cmd.Parameters.AddWithValue("@Hotel_Description", hotel_details.hotel_desc);
                cmd.Parameters.AddWithValue("@No_Of_Rooms", hotel_details.no_of_rooms);
                cmd.Parameters.AddWithValue("@Rent_Of_Rooms", hotel_details.rent_of_room);
                cmd.Parameters.AddWithValue("@Offer_Name", hotel_details.offer_id);
                return cmd.ExecuteNonQuery().ToString();
            }
            catch (Exception show_error)
            {
                throw show_error;
            }
            finally
            {
                cmd.Dispose();
                con.Close();
                con.Dispose();
            }
        }

        public string Payments(payment_object obPay)
        {
            con.Open();
           

            SqlCommand cmd = new SqlCommand("sp_payments", con);

            cmd.CommandType = CommandType.StoredProcedure;
            try
            {
                cmd.Parameters.AddWithValue("@pid", obPay.pid);
                cmd.Parameters.AddWithValue("@bankname", obPay.bankname);

                cmd.Parameters.AddWithValue("@cardtype", obPay.cardtype);

                cmd.Parameters.AddWithValue("@namecard", obPay.nameoncard);

                cmd.Parameters.AddWithValue("@cardnumber", obPay.cardnum);

                cmd.Parameters.AddWithValue("@expirydate", obPay.expirydate);
                return cmd.ExecuteNonQuery().ToString();
            }
            catch (Exception show_error)
            {
                throw show_error;
            }
            finally
            {
                cmd.Dispose();
                con.Close();
                con.Dispose();
            }
   

        }

        

        public string Hotel_Update(hotel_object hotel_details)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("update_hotel_sp", con);
            cmd.CommandType = CommandType.StoredProcedure;
            try
            {
                cmd.Parameters.AddWithValue("@Hotel_Name", hotel_details.hotel_name);
                cmd.Parameters.AddWithValue("@City_Name", hotel_details.city_name);
                cmd.Parameters.AddWithValue("@Hotel_Description", hotel_details.hotel_desc);
                cmd.Parameters.AddWithValue("@No_Of_Rooms", hotel_details.no_of_rooms);
                cmd.Parameters.AddWithValue("@Rent_Of_Rooms", hotel_details.rent_of_room);
                cmd.Parameters.AddWithValue("@Offer_Name", hotel_details.offer_id);
                return cmd.ExecuteNonQuery().ToString();
            }
            catch (Exception show_error)
            {
                throw show_error;
            }
            finally
            {
                cmd.Dispose();
                con.Close();
                con.Dispose();
            }
        }


        public DataSet Search(hotel_object user_details)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("search_sp", con);
            cmd.CommandType = CommandType.StoredProcedure;
            try
            {
                cmd.Parameters.AddWithValue("@cityname", user_details.city_name);
                cmd.Parameters.AddWithValue("@noofrooms", user_details.no_of_rooms);
                //cmd.ExecuteScalar();
                DataSet DS = new DataSet();
                SqlDataAdapter SDA = new SqlDataAdapter(cmd);
                SDA.Fill(DS);
                return DS;
            }
            catch (Exception show_error)
            {
                throw show_error;
            }

            finally
            {
                cmd.Dispose();
                con.Close();
                con.Dispose();
            }
        }

        //here we insert booking
        public string booking(booking_object hotel_details)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("booking_sp", con);
            cmd.CommandType = CommandType.StoredProcedure;
            try
            {
                cmd.Parameters.AddWithValue("@id", Convert.ToInt32(hotel_details.id));
                cmd.Parameters.AddWithValue("@noofrooms",  Convert.ToInt32(hotel_details.noofrooms));
                cmd.Parameters.AddWithValue("@hotelname", hotel_details.hotelname);
                cmd.Parameters.AddWithValue("@amount", hotel_details.amount);
                cmd.Parameters.AddWithValue("@Cname", hotel_details.Cname);
                //cmd.Parameters.AddWithValue("@Offer_Name", hotel_details.offer_id);
                return cmd.ExecuteNonQuery().ToString();
            }
            catch (Exception show_error)
            {
                throw show_error;
            }
            finally
            {
                cmd.Dispose();
                con.Close();
                con.Dispose();
            }
        }

        /* create proc booking_sp
         * (
         * @id
         * @noofrooms
         * @hotelname
         * @amount
         * @Cname
         * )
         as
         insert into Booking(Id,Noofrooms,Hotelname,Amount,Customername) Values(@id,@noofrooms,@hotelname,@amount,@Cname)
         return;
         */
        public DataSet BookSearch(booking_object user_details)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("search_booking_sp", con);
            cmd.CommandType = CommandType.StoredProcedure;
            try
            {
                cmd.Parameters.AddWithValue("@id", user_details.id);
               //cmd.Parameters.AddWithValue("@noofrooms", user_details.no_of_rooms);
               //cmd.ExecuteScalar();
                DataSet DS = new DataSet();
                SqlDataAdapter SDA = new SqlDataAdapter(cmd);
                SDA.Fill(DS);
                return DS;
            }
            catch (Exception show_error)
            {
                throw show_error;
            }

            finally
            {
                cmd.Dispose();
                con.Close();
                con.Dispose();
            }
        }

        public string Payments_Details(paymentdetails payment_details)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("payment_detail_sp", con);
            cmd.CommandType = CommandType.StoredProcedure;
            try
            {
                cmd.Parameters.AddWithValue("@pid", payment_details.PID);
                cmd.Parameters.AddWithValue("@bid", payment_details.BID);
                cmd.Parameters.AddWithValue("@status", payment_details.status);
                cmd.Parameters.AddWithValue("@amount", payment_details.amount);
                //cmd.Parameters.AddWithValue("@cname", payment_details.Cname);
                //cmd.Parameters.AddWithValue("@Offer_Name", hotel_details.offer_id);
                return cmd.ExecuteNonQuery().ToString();
            }


                /*create proc payment_detail_sp
                 (
                 * @pid bigint,
                 * @bid bigint,
                 * @status varchar(50),
                 * @amount varchar(50),
                 * @cname varchar(50),
                 )
                 as
                 insert into Payment_Details Values(@pid,@bid,@status,@amount)
                 update reg set Balance=Balance-Convert(bigint,@amount) where Name=@cname
                 return;*/
            catch (Exception show_error)
            {
                throw show_error;
            }
            finally
            {
                cmd.Dispose();
                con.Close();
                con.Dispose();
            }
        }

        public string Update_Balance(Updatebalance update_details)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("update_reg_deduct", con);
            cmd.CommandType = CommandType.StoredProcedure;
            try
            {
                cmd.Parameters.AddWithValue("@cname", update_details.cname);
                cmd.Parameters.AddWithValue("@amount", int.Parse(update_details.amount));
                return cmd.ExecuteNonQuery().ToString();
            }


            catch (Exception show_error)
            {
                throw show_error;
            }
            finally
            {
                cmd.Dispose();
                con.Close();
                con.Dispose();
            }
        }


        public DataSet Show_Customer(register_object user_details)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("show_customer", con);
            cmd.CommandType = CommandType.StoredProcedure;
            try
            {
                cmd.Parameters.AddWithValue("@Cname", user_details.name);
//                cmd.Parameters.AddWithValue("@noofrooms", user_details.no_of_rooms);
                //cmd.ExecuteScalar();
                DataSet DS = new DataSet();
                SqlDataAdapter SDA = new SqlDataAdapter(cmd);
                SDA.Fill(DS);
                return DS;
            }
            catch (Exception show_error)
            {
                throw show_error;
            }

            finally
            {
                cmd.Dispose();
                con.Close();
                con.Dispose();
            }
        }


        public string Cancel_Booking(paymentdetails payment_details)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("cancel_booking", con);
            cmd.CommandType = CommandType.StoredProcedure;
            try
            {
                cmd.Parameters.AddWithValue("@pid", payment_details.PID);
                cmd.Parameters.AddWithValue("@bid", payment_details.BID);
                //cmd.Parameters.AddWithValue("@status", payment_details.status);
                //cmd.Parameters.AddWithValue("@amount", payment_details.amount);
                //cmd.Parameters.AddWithValue("@cname", payment_details.Cname);
                //cmd.Parameters.AddWithValue("@Offer_Name", hotel_details.offer_id);
                return cmd.ExecuteNonQuery().ToString();
            }
            catch (Exception show_error)
            {
                throw show_error;
            }
            finally
            {
                cmd.Dispose();
                con.Close();
                con.Dispose();
            }
        }

     
    }
}