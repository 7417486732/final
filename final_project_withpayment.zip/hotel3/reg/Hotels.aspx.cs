﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace reg
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Label1.Text = Session["Cname"].ToString();
            Session["Cname"] = Label1.Text;
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow gr = GridView1.SelectedRow;
            Session["hotelnm"] = gr.Cells[1].Text;
            Session["rentofroom"] = gr.Cells[5].Text;
            Response.Redirect("doingBooking.aspx");
        }
    }
}