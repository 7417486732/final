﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BUSINESS_OBJECT;
using BAL;

namespace reg
{
    public partial class WebForm8 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Random r = new Random();
            TextBox2.Text = r.Next().ToString() ;
            TextBox3.Text = Session["BID"].ToString();
            TextBox4.Text = Session["Cname"].ToString();
            TextBox5.Text = Session["amount"].ToString();
        }

       

        protected void Button1_Click(object sender, EventArgs e)
        {
            payment_object ob1 = new payment_object();
            register_bal addpay = new register_bal();
            ob1.pid = TextBox2.Text;
            ob1.bankname = DropDownList3.SelectedValue;

            ob1.cardtype = CardType.SelectedItem.Text.ToString();

            ob1.nameoncard = cardname.Text;

            ob1.cardnum = cardno.Text;

            ob1.expirydate = TextBox1.Text;

           string msg = addpay.Payments(ob1);

           if (!msg.Equals("Success"))
           {
               //Here we update the payment details ...
               //update procedure should deduct the amount from database.



               paymentdetails ob2 = new paymentdetails();
               register_bal addpay1 = new register_bal();
               ob2.PID = TextBox2.Text;
               ob2.BID = TextBox3.Text;
               ob2.status = "deduct";
               ob2.amount = TextBox5.Text;


               string msg1 = addpay.Payments_Details(ob2);

               if (!msg1.Equals("Success"))
               {
                   Updatebalance ob3 = new Updatebalance();
                   register_bal addpay2 = new register_bal();
                   
                   ob3.cname = TextBox4.Text;
                   ob3.amount = TextBox5.Text;
                   string msg2 = addpay.update_balance(ob3);
                   register_object ro = new register_object();
                   ro.name = TextBox4.Text;
                   if (!msg2.Equals("Success"))
                   {
                       Label1.Text = "Payment Success";
                       TextBox1.Text = "";
                       GridView1.DataSource = addpay2.showcustomer(ro);
                       GridView1.DataBind();
                   }
                   else
                   {
                       Label1.Text = "Payment Failed";
                   }
               }
           }
            //here we have to write the calling of payment details 
            //status = deduct
            //and send PID, BID,status,amount,Cname
            //two queries will be written....
            //one is insert into payment details
            //another is update customer balance



        }

        
    }
}