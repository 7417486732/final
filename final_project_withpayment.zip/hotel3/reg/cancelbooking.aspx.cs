﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BAL;
using BUSINESS_OBJECT;

namespace reg
{
    public partial class WebForm19 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        
            Label5.Text = Session["Cname"].ToString();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //Here we write update Payment details
            //we add the amount to the databse.


            //payment_object ob1 = new payment_object();
            //register_bal addpay = new register_bal();
            //ob1.pid = TextBox2.Text;
            //ob1.bankname = DropDownList3.SelectedValue;

            //ob1.cardtype = CardType.SelectedItem.Text.ToString();

            //ob1.nameoncard = cardname.Text;

            //ob1.cardnum = cardno.Text;

            //ob1.expirydate = TextBox1.Text;

            //string msg = addpay.Payments(ob1);

            //if (!msg.Equals("Success"))
            //{
            //    //Here we update the payment details ...
            //    //update procedure should deduct the amount from database.



            paymentdetails ob2 = new paymentdetails();
            register_bal addpay1 = new register_bal();
            register_object ro = new register_object();

            ob2.PID = TextBox2.Text;
            ob2.BID = TextBox1.Text;
            ob2.status = "add";
            //ob2.amount = TextBox5.Text;


            string msg1 = addpay1.cancelbooking(ob2);

            //if (!msg1.Equals("Success"))
            //{
            //    Updatebalance ob3 = new Updatebalance();
            //    register_bal addpay2 = new register_bal();

            //    ob3.cname = TextBox4.Text;
            //    ob3.amount = TextBox5.Text;
            //    string msg2 = addpay.update_balance(ob3);

            if (!msg1.Equals("Success"))
            {
                Label2.Text = "Booking Cancelled";
                TextBox1.Text = "";
                GridView1.Visible = true;
                Label2.Visible = true;
            }
            else
            {
                Label2.Text = "Payment Failed";
            }
        }
    }
}