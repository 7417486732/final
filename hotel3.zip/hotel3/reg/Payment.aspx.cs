﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BUSINESS_OBJECT;
using BAL;

namespace reg
{
    public partial class WebForm8 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            payment_object ob1 = new payment_object();
            register_bal addpay = new register_bal();
            ob1.bankname = DropDownList3.SelectedItem.Text.ToString();

            ob1.cardtype = CardType.SelectedItem.Text.ToString();

            ob1.nameoncard = cardname.Text;

            ob1.cardnum = cardno.Text;

            ob1.expirydate = TextBox1.Text;

           string msg = addpay.Payments(ob1);

           if (!msg.Equals("Success"))
            {

                Label1.Text = "Payment Success";

            }

            else
            {

                Label1.Text = "Payment Failed";

            }
        }

        
    }
}